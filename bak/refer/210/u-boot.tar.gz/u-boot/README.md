##ok210上使用DNW
###
    u-boot    : uboot_ok210.tar.gz
     - u-boot-210.bin
     
    dnw-linux : https://github.com/changbindu/dnw-linux
     -
    
    arm-linux-gcc : OK210用户光盘（A）/实用工具/arm-2009q3.tar.bz2
     -
     
    rootfs    : OK210用户光盘（A）/Linux/Demo(Linux2.6.35.7)/sdfuse/rootfs-210.yaffs2
     - rootfs-210.yaffs2 
     
    kernel    : OK210用户光盘（A）/Linux/Demo(Linux2.6.35.7)/sdfuse/zImage-210              
     - zImage-210 
     
    注意事项:在ok210的uboot启动前拔掉usb线,uboot启动后再插入usb线，完成一些烧写操作！
